import React from 'react';

const Page2 = props => {
  return (
    <div className="page-two">
      <h2>Page 2: Can be shown through tabs</h2>
    </div>
  )
}

export default Page2