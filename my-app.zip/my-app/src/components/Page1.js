import React from 'react';

const Page1 = props => {
  return (
    <div className="page-one">
      <h1>Page 1: Display By Default</h1>
    </div>
  )
}

export default Page1;